Oktay & Corina Puzzle – Android-Web-App-Projekt

Enthalten:
- index.html: spielbares Puzzle für Handy und Desktop
- puzzle.jpg: Motiv (falls verfügbar)

So testen:
1. index.html im Browser öffnen.
2. Teile durch Antippen zweier Felder tauschen.
3. Schwierigkeit auswählen oder eigenes Bild laden.

Wichtig:
Dies ist eine offlinefähige Web-App-Datei, keine bereits kompilierte APK.
Zum Erstellen einer installierbaren APK muss das Projekt in Android Studio in eine
Android-WebView-App verpackt und mit dem Android SDK gebaut werden. In dieser
Umgebung ist kein Android SDK/Gradle installiert, daher kann ich keine echte APK
kompilieren oder verifizieren.
