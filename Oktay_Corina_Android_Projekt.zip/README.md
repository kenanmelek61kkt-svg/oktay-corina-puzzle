# Oktay & Corina Puzzle Android

Android-WebView-App, die `index.html` und `puzzle.jpg` lokal aus `app/src/main/assets/` lädt.
Das Puzzle kann daher ohne Internet gespielt werden.

## APK über GitHub Actions bauen
Das Projekt enthält Gradle-Dateien. Mit Java 17, Gradle 8.7 und Android SDK Platform 35
kann `gradle assembleDebug` die Debug-APK erzeugen.
